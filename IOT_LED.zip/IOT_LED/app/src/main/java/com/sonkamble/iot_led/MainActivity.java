package com.sonkamble.iot_led;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private Button ledOn, ledOff;
    ProgressDialog progressDoalog;
    ImageView img_on_off;
    TextView txt_msg;
    String url="https://codingseekho.in/APP/IOT/status.php?";
    String surl="https://codingseekho.in/APP/IOT/Getstatus.php?";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt_msg=findViewById(R.id.txt_msg);
        img_on_off=findViewById(R.id.img_on_off);
        ledOn=findViewById(R.id.btn_ledOn);
        ledOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update(1);
            }
        });
        ledOff=findViewById(R.id.btn_ledOff);
        ledOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update(0);

            }
        });
        load_data();
    }

    public void load_data()
    {
        {   progressDoalog = new ProgressDialog(MainActivity.this);
            progressDoalog.setMessage("Loading Status....");
            progressDoalog.show();

            JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.POST, surl, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    progressDoalog.dismiss();
                    //Toast.makeText(getApplicationContext(),"Responce"+response,Toast.LENGTH_LONG).show();
                    try
                    {
                        if(response != null){
                            JSONObject jsonObject = new JSONObject(response.toString());
                            JSONObject postobject = jsonObject.getJSONObject("posts");
                            String status = postobject.getString("val");
                            if (status.equals("1")) {
                                img_on_off.setImageDrawable(ContextCompat.getDrawable(MainActivity.this, R.drawable.on));
                                txt_msg.setText("LED IS ON");
                            }
                            else
                            {
                                img_on_off.setImageDrawable(ContextCompat.getDrawable(MainActivity.this, R.drawable.off));
                                txt_msg.setText("LED IS OFF");
                            }
                        }
                    }catch (Exception e){}
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });

            MySingleton.getInstance(MainActivity.this).addToRequestque(jsonObjectRequest);
        }

    }
     void update(int val)
     {
         progressDoalog = new ProgressDialog(MainActivity.this);
         progressDoalog.setMessage("Updating Status..");
         progressDoalog.show();

         StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
             @Override
             public void onResponse(String response) {
                // Toast.makeText(MainActivity.this, "response:"+response, Toast.LENGTH_SHORT).show();
                 try {
                     if (response != null) {
                         // progressbar.setVisibility(View.INVISIBLE);
                         progressDoalog.dismiss();
                         JSONObject jsonObject = new JSONObject(response.toString());
                         JSONObject postobject = jsonObject.getJSONObject("posts");

                         String status = postobject.getString("status");
                         //String client_status = postobject.getString("client_status");
                         if (status.equals("200")) {
                             // clear_text();
                             Intent i=new Intent(getApplicationContext(),MainActivity.class);
                             startActivity(i);
                             Toast.makeText(getApplicationContext(), "Updated Successfully..!!", Toast.LENGTH_SHORT).show();
                         } else if (status.equals("401")) {
                             // english_poemList.clear();
                           //  Toast.makeText(getApplicationContext(), "Error:" + status, Toast.LENGTH_LONG).show();
                         }

                     } else {
                        // Toast.makeText(getApplicationContext(), "No dat found ... please try again", Toast.LENGTH_SHORT).show();
                     }
                 } catch (JSONException e) {
                     e.printStackTrace();
                 }
             }
         }, new Response.ErrorListener() {
             @Override
             public void onErrorResponse(VolleyError error) {
                 Toast.makeText(getApplicationContext(),"Something went wrong", Toast.LENGTH_LONG).show();
                 error.printStackTrace();
             }
         })
         {@Override
         protected Map<String, String> getParams() throws AuthFailureError {
             Map<String,String> param=new HashMap<String, String>();
             param.put("val",""+val);
             return param;
         }
         };
         MySingleton.getInstance(MainActivity.this).addToRequestque(stringRequest);
     }
}